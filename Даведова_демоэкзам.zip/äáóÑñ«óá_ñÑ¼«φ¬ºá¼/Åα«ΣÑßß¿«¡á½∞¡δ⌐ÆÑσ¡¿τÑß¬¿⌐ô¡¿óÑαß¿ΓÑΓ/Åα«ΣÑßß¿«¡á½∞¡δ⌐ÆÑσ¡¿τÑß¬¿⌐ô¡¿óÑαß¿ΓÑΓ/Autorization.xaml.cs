﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ПрофессиональныйТехническийУниверситет
{
    /// <summary>
    /// Логика взаимодействия для Autorization.xaml
    /// </summary>
    public partial class Autorization : Window
    {
        public Autorization()
        {
            InitializeComponent();
        }

        BRS1Entities ef = new BRS1Entities();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(ef.Пользователи.Where(r=>r.Логин==TextBoxlog.Text && r.Пароль==TextBoxpas.Text). Count()>0)
                {
                    MainWindow mw = new MainWindow();
                    mw.Show();
                    this.Hide();
                }
                else
                {
                    TextBoxlog.Text = "";
                    TextBoxpas.Text = "";
                    MessageBox.Show("Неверный логин или пароль");
                }
            }
            catch { }
        }
    }
}
